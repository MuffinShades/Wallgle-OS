var section = document.getElementById('c-m-d');
section.focus();
section.innerHTML = '';

const _SAFE = true;

var clear_click = false;

function read(a) {
    a();
}

var stx = void 0;

var runCmd = void 0;
var read_clear = false;

function cursorSelect(pos) {
    section.focus();
    section.setSelectionRange(pos,pos);
}

function requireText(txt) {
    stx = txt;
}

setInterval(function() {
    //resize
    document.getElementById('launch-obx-frame').style.width = document.documentElement.clientWidth;
    document.getElementById('launch-obx-frame').style.height = document.documentElement.clientHeight;
    document.getElementById('launch-box').style.width = document.documentElement.clientWidth;
    document.getElementById('launch-box').style.height = document.documentElement.clientHeight;
    if (section.value.toString().replace(stx, '') == section.value.toString()) {
        section.value = stx;
    }
});

var bootFile = void 0;

var loadQuery = 'Please type name of folder to boot from (In the Installs< folder): \n';

var log = '';
var logging = false;

if (section) {
    section.value = loadQuery;
    requireText(loadQuery);
    cursorSelect(section.value.length);
    log = '';
    logging = true;
    runCmd = function() {
        requireText(section.value);
        bootFile = '../Installs/'+log;
        console.log('Booting From: '+bootFile);
        section.value += 'Would you like to boot? Y/N \n';
        requireText(section.value);
        log = '';
        logging = true;
        runCmd = function() {
            //launch
            if (log.toLowerCase() == 'y') {
                var launcher = document.createElement('script');
                launcher.src = bootFile+'/launch.js';
                document.body.appendChild(launcher);
                console.log('System: '+bootFile + '/Core/all.html');
                location = bootFile + '/Core/all.html';
                document.getElementById('launch-box').style.display = 'block';
                section.style.display = 'none';
            } else if (log.toLowerCase() == 'n') {
                window.close();
            }
        }
    }
    read_clear = true;
}

document.onkeydown = function(e) {
    if (clear_click) {
        section.innerHTML = '';
        clear_click = false;
    }
    if (e.keyCode == 13) {
        console.log('!');
        logging = false;
        setTimeout(function() {
            if (runCmd != void 0) {
                read(runCmd);
            }
        });
    }

    //key logger
    if (logging == true) {
        if (e.key != 'Shift' &&e.key != 'Enter' &&e.key != 'Backspace' &&e.key != 'Tab' &&e.key != 'Capslock' &&e.key !=  'Ctrl') {
            log += e.key;
        } else if (e.key == 'Backspace') {
            log = log.slice(0, log.length - 1);
        }
    }
}