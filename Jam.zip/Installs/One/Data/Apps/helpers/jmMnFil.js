var MAIN_FILES = [
    {
        name: 'App Adder',
        src: 'Main/aa',
        img: 'icon.png',
        file: 'AppAdd.html',
        openHeight: 500,
        openWidth: 500,
    }
];

var CUSTOM_FILES = [
    
];