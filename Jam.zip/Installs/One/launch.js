/*if (_SAFE == true) {

}else{window.close();}*/