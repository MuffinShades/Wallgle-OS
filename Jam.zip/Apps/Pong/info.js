var appName = 'Pong';
var appIcon = 'icon.png';
var appHTML = 'Data/png.html';
var appOpenHeight = 300;
var appOpenWidth = 300;
var appWindowType = 'file';